package com.boolumer.stream

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/** The dashboard: greeting, balance card, Withdraw / Referral / History, Task Drop + the music list. */
class HomeActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var loadMore: View
    private lateinit var empty: View
    private lateinit var usd: TextView
    private var shown = 0
    private var scanning = false
    private var scannedOnce = false
    private var lastBack = 0L

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Store.setPermissionAsked(this)
        if (granted) scan() else {
            showEmpty(true)
            U.toast(this, "Music access is needed to list your songs")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home)
        U.edgeToEdge(this)

        list = findViewById(R.id.linear3)
        loadMore = findViewById(R.id.Dbt)
        empty = findViewById(R.id.NONBG)
        (loadMore.parent as? ViewGroup)?.removeView(loadMore)

        findViewById<View>(R.id.lin1).setOnClickListener { sheet(WithdrawDialogFragmentActivity(), "withdraw") }
        findViewById<View>(R.id.lin2).setOnClickListener { sheet(ReferralDialogFragmentActivity(), "referral") }
        findViewById<View>(R.id.lin3).setOnClickListener { sheet(HistoryDialogFragmentActivity(), "history") }
        findViewById<View>(R.id.imageview21).setOnClickListener { ensureMusicAccess() }   // refresh
        findViewById<View>(R.id.textview4).setOnClickListener { startActivity(Intent(this, TaskActivity::class.java)) }
        val profile = View.OnClickListener { sheet(ProfileDialogFragmentActivity(), "profile") }
        findViewById<View>(R.id.hello_name).setOnClickListener(profile)
        findViewById<View>(R.id.cardview2).setOnClickListener(profile)
        findViewById<View>(R.id.hello_name).setOnLongClickListener { DemoNav.show(this); true }
        empty.setOnClickListener { ensureMusicAccess() }
        loadMore.setOnClickListener { addPage() }

        // the "≈ $0.000" pill replaces the shimmer placeholder in the balance card
        val sk = findViewById<View>(R.id.cardLoad1)
        val row = sk.parent as ViewGroup
        sk.visibility = View.GONE
        usd = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
            setPadding(U.dp(context, 12f), U.dp(context, 5f), U.dp(context, 12f), U.dp(context, 5f))
            background = U.round(0xFF000000.toInt(), U.dp(context, 100f).toFloat(), false)
        }
        row.addView(usd, row.indexOfChild(sk))
        U.applyFont(usd)

        val n = Store.name(this)
        findViewById<TextView>(R.id.hello_name).text = "Hi, " + (if (n.isEmpty()) "there" else n.split(" ")[0])
        showEmpty(false)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (System.currentTimeMillis() - lastBack < 1800) finish()
                else { lastBack = System.currentTimeMillis(); U.toast(this@HomeActivity, "Press back again to exit") }
            }
        })
        ensureMusicAccess()
    }

    override fun onResume() {
        super.onResume()
        paintBalance()
        // came back from Settings after granting access
        if (!scannedOnce && !scanning && MusicPermission.isGranted(this)) scan()
    }

    private fun sheet(d: BaseDialog, tag: String) {
        d.onClosed = { paintBalance() }
        d.show(supportFragmentManager, tag)
    }

    private fun paintBalance() {
        val s = U.num(Math.floor(Store.coins(this) * 100) / 100.0, 2) // 1,234.56
        val dot = s.lastIndexOf('.')
        findViewById<TextView>(R.id.textview1).text = s.substring(0, dot + 1)
        findViewById<TextView>(R.id.textview6).text = s.substring(dot + 1)
        usd.text = "≈ $" + String.format(Locale.US, "%.3f", Store.usd(this))
    }

    private fun showEmpty(on: Boolean) { empty.visibility = if (on) View.VISIBLE else View.GONE }

    // ---------- music access ----------
    private fun ensureMusicAccess() {
        when {
            MusicPermission.isGranted(this) -> scan()
            supportFragmentManager.findFragmentByTag("perm") != null -> Unit
            else -> {
                val d = PermissionDialogFragment()
                d.openSettings = MusicPermission.isPermanentlyDenied(this)
                d.onAllow = { permLauncher.launch(MusicPermission.permission) }
                d.onLater = { showEmpty(true) }
                d.show(supportFragmentManager, "perm")
            }
        }
    }

    private fun scan() {
        if (scanning) return
        scanning = true
        skeleton()
        lifecycleScope.launch {
            delay(350)
            MusicRepository.refresh(applicationContext)
            scanning = false
            scannedOnce = true
            list.removeAllViews()
            shown = 0
            showEmpty(MusicRepository.songs.isEmpty())
            addPage()
        }
    }

    private fun skeleton() {
        list.removeAllViews()
        showEmpty(false)
        repeat(3) { list.addView(LayoutInflater.from(this).inflate(R.layout.music_load, list, false)) }
    }

    private fun addPage() {
        (loadMore.parent as? ViewGroup)?.removeView(loadMore)
        val songs = MusicRepository.songs
        val end = minOf(songs.size, shown + PAGE)
        for (i in shown until end) list.addView(row(i))
        shown = end
        if (shown < songs.size) list.addView(loadMore)
    }

    private fun row(index: Int): View {
        val s = MusicRepository.songs[index]
        val v = LayoutInflater.from(this).inflate(R.layout.music_ls, list, false)
        v.findViewById<TextView>(R.id.title1).text = s.title
        v.findViewById<TextView>(R.id.d1).text = U.mmss(s.durationMs)
        v.findViewById<TextView>(R.id.coin1).text = s.reward.toString()
        v.findViewById<View>(R.id.bin).setBackgroundColor(0xFF1B1B1B.toInt())
        val open = View.OnClickListener {
            startActivity(Intent(this, StreamerActivity::class.java).putExtra("index", index))
        }
        v.findViewById<View>(R.id.textBt).setOnClickListener(open)
        v.setOnClickListener(open)
        U.applyFont(v)
        return v
    }

    private companion object { const val PAGE = 8 }
}
