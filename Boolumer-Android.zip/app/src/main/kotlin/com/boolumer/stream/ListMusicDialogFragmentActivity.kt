package com.boolumer.stream

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** "Music List" queue opened from the Streamer. */
class ListMusicDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.list_music_dialog_fragment
    var onPick: ((Int) -> Unit)? = null

    override fun bind(root: View) {
        click(root.f(R.id.imageview11)) { dismiss() }
        root.f<View>(R.id.recyclerview2).visibility = View.GONE
        val list = root.f<RecyclerView>(R.id.recyclerview1)
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(p.context).inflate(R.layout.music_ls, p, false)
                return object : RecyclerView.ViewHolder(v) {}
            }

            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val s = MusicRepository.songs[pos]
                val v = h.itemView
                U.applyFont(v)
                v.findViewById<TextView>(R.id.title1).text = s.title
                v.findViewById<TextView>(R.id.d1).text = U.mmss(s.durationMs)
                v.findViewById<TextView>(R.id.coin1).text = s.reward.toString()
                v.findViewById<TextView>(R.id.textBt).text = "Play"
                v.findViewById<View>(R.id.bin).setBackgroundColor(0xFF1B1B1B.toInt())
                val pick = View.OnClickListener { dismiss(); onPick?.invoke(pos) }
                v.setOnClickListener(pick)
                v.findViewById<View>(R.id.textBt).setOnClickListener(pick)
            }

            override fun getItemCount() = MusicRepository.songs.size
        }
    }
}
