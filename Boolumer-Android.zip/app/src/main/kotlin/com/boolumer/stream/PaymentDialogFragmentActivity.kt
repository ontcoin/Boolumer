package com.boolumer.stream

import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

/** Payment: pick an exchange and save your deposit ID (stored on this phone). */
class PaymentDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.payment_dialog_fragment
    private var selected = "Binance"
    private lateinit var root: View
    private val icons = arrayOf("binance-svgrepo-com.svg", "kucoin-svgrepo-com.svg", "bitget-token-new-bgb-logo.svg", null)
    private val imgs = intArrayOf(R.id.imageview17, R.id.imageview18, R.id.imageview21, R.id.imageview19)
    private val lbls = intArrayOf(R.id.textview13, R.id.textview14, R.id.textview17, R.id.textview15)

    override fun bind(root: View) {
        this.root = root
        click(root.f(R.id.imageview11)) { dismiss() }
        for (i in 0 until 4) {
            val iv = root.f<ImageView>(imgs[i])
            icons[i]?.let { U.svg(requireContext(), iv, it) } ?: iv.setImageResource(R.drawable.ic_litoshi)
            val ex = Store.EXCHANGES[i]
            click(root.f(lbls[i])) { selected = ex; refresh() }
            iv.setOnClickListener { selected = ex; refresh() }
        }
        val wallet = root.f<ImageView>(R.id.imageview15)
        if (wallet.drawable == null) wallet.setImageResource(R.drawable.icon_business_center_twotone)
        Store.activeExchange(requireContext()).takeIf { it.isNotEmpty() }?.let { selected = it }
        root.f<View>(R.id.lottie1).visibility = View.GONE
        click(root.f(R.id.textview12)) {
            val field = root.f<EditText>(R.id.edittext1)
            val id = field.text.toString().trim()
            when {
                id.isEmpty() -> U.toast(requireContext(), "Enter your $selected ID")
                selected == "Litoshi" -> U.toast(requireContext(), "Coming soon")
                else -> {
                    Store.setWallet(requireContext(), selected, id)
                    field.setText("")
                    refresh()
                    U.toast(requireContext(), "ID saved")
                }
            }
        }
        refresh()
    }

    private fun refresh() {
        val id = Store.wallet(requireContext(), selected)
        root.f<TextView>(R.id.address).text = if (id.isEmpty()) "No ID added" else "$selected: $id"
        root.f<View>(R.id.soon).visibility = if (selected == "Litoshi") View.VISIBLE else View.GONE
        for (i in 0 until 4) {
            (root.f<TextView>(lbls[i]).parent as View).alpha = if (Store.EXCHANGES[i] == selected) 1f else 0.45f
        }
    }
}
