package com.boolumer.stream

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.PictureDrawable
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.caverock.androidsvg.SVG
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/** Small helpers shared by every screen. */
object U {
    fun dp(c: Context, v: Float): Int = Math.round(v * c.resources.displayMetrics.density)

    /** Targeting Android 15+ makes apps edge-to-edge; this keeps every screen clear of the status/navigation bars. */
    fun edgeToEdge(a: Activity) {
        WindowCompat.setDecorFitsSystemWindows(a.window, false)
        ViewCompat.setOnApplyWindowInsetsListener(a.findViewById<View>(android.R.id.content)) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        applyFont(a.findViewById(android.R.id.content))
    }

    private var font: Typeface? = null

    /** Applies the app font (Poppins, from /assets/fonts) to every TextView under [v], keeping bold/italic. */
    fun applyFont(v: View) {
        val f = font ?: try {
            Typeface.createFromAsset(v.context.assets, "fonts/poopins.ttf").also { font = it }
        } catch (_: Exception) { return }
        if (v is TextView) v.setTypeface(f, v.typeface?.style ?: Typeface.NORMAL)
        if (v is ViewGroup) for (i in 0 until v.childCount) applyFont(v.getChildAt(i))
    }

    fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

    fun open(c: Context, url: String) {
        try {
            c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast(c, "Can't open link")
        }
    }

    fun copy(c: Context, text: String) {
        val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("boolumer", text))
        toast(c, "Copied")
    }

    /** Rounded background. topOnly = bottom-sheet style (only the top corners are rounded). */
    fun round(color: Int, radiusPx: Float, topOnly: Boolean): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        if (topOnly) cornerRadii = floatArrayOf(radiusPx, radiusPx, radiusPx, radiusPx, 0f, 0f, 0f, 0f)
        else cornerRadius = radiusPx
    }

    fun bgColor(v: View, fallback: Int): Int = (v.background as? ColorDrawable)?.color ?: fallback

    /** Renders an SVG from /assets into an ImageView (androidsvg). */
    fun svg(c: Context, iv: ImageView, asset: String) {
        try {
            val svg = SVG.getFromAsset(c.assets, asset)
            iv.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            iv.setImageDrawable(PictureDrawable(svg.renderToPicture()))
        } catch (_: Exception) {
        }
    }

    fun num(v: Double, decimals: Int): String {
        val p = StringBuilder("#,##0")
        if (decimals > 0) p.append('.').append("0".repeat(decimals))
        return DecimalFormat(p.toString(), DecimalFormatSymbols.getInstance(Locale.US)).format(v)
    }

    fun mmss(ms: Long): String {
        val s = maxOf(0L, ms / 1000)
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    fun sizeText(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024 * 1024))
        bytes >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024))
        bytes >= 1L shl 10 -> String.format(Locale.US, "%d KB", bytes / 1024)
        else -> "$bytes B"
    }
}
