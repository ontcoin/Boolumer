package com.boolumer.stream

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.history_dialog_fragment

    override fun bind(root: View) {
        click(root.f(R.id.imageview11)) { dismiss() }
        root.f<View>(R.id.recyclerview2).visibility = View.GONE
        val list = root.f<RecyclerView>(R.id.recyclerview1)
        val h = Store.history(requireContext())
        val empty = h.length() == 0
        root.f<View>(R.id.imageview5).visibility = if (empty) View.VISIBLE else View.GONE
        root.f<View>(R.id.textview5).visibility = if (empty) View.VISIBLE else View.GONE
        list.visibility = if (empty) View.GONE else View.VISIBLE
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = object : RecyclerView.Adapter<VH>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int) =
                VH(LayoutInflater.from(p.context).inflate(R.layout.his, p, false))

            override fun onBindViewHolder(vh: VH, pos: Int) {
                U.applyFont(vh.itemView)
                val o = h.getJSONObject(h.length() - 1 - pos) // newest first
                vh.title.text = o.optString("title")
                vh.date.text = o.optString("date")
                val a = o.optDouble("amount")
                vh.amount.text = (if (a >= 0) "+" else "") + U.num(a, if (a == Math.floor(a)) 0 else 2)
                vh.status.text = o.optString("status")
                vh.status.setTextColor(if (o.optString("status") == "Pending") 0xFFFFD700.toInt() else 0xFF4CAF50.toInt())
            }

            override fun getItemCount() = h.length()
        }
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.title)
        val date: TextView = v.findViewById(R.id.date)
        val amount: TextView = v.findViewById(R.id.amount)
        val status: TextView = v.findViewById(R.id.status)
    }
}
