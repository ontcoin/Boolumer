package com.boolumer.stream

import android.view.View
import android.widget.TextView

/** Referral: share your code, 5% of friends' claims (simulated). */
class ReferralDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.referral_dialog_fragment
    private lateinit var root: View

    override fun bind(root: View) {
        this.root = root
        click(root.f(R.id.imageview11)) { dismiss() }
        root.f<View>(R.id.lottie1).visibility = View.GONE
        root.f<TextView>(R.id.textview18).text = Store.refCode(requireContext())
        click(root.f(R.id.textview19)) { U.copy(requireContext(), Store.refCode(requireContext())) }
        click(root.f(R.id.TXT)) {
            if (Store.refReward(requireContext()) <= 0) {
                U.toast(requireContext(), "Nothing to claim yet")
            } else {
                Store.claimRefReward(requireContext())
                paint()
                U.toast(requireContext(), "Reward claimed")
            }
        }
        paint()
    }

    private fun paint() {
        val rw = Store.refReward(requireContext())
        root.f<TextView>(R.id.textview6).text = U.num(rw, 2)
        root.f<TextView>(R.id.textview20).text = Store.friends(requireContext()).toString()
        root.f<TextView>(R.id.textview22).text = U.num(rw, 1)
    }
}
