package com.boolumer.stream

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Shows the stack trace of an uncaught crash instead of silently closing the app. */
class DebugActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val err = intent.getStringExtra("error") ?: "No details"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(U.dp(context, 16f), U.dp(context, 24f), U.dp(context, 16f), U.dp(context, 16f))
        }
        root.addView(TextView(this).apply { text = "Something went wrong"; setTextColor(0xFFFFD700.toInt()); textSize = 20f })
        val sv = ScrollView(this)
        sv.addView(TextView(this).apply { text = err; setTextColor(Color.WHITE); textSize = 11f; setTextIsSelectable(true) })
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(Button(this).apply { text = "Copy error"; setOnClickListener { U.copy(context, err) } })
        row.addView(Button(this).apply {
            text = "Restart app"
            setOnClickListener {
                startActivity(Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                finish()
            }
        })
        root.addView(row)
        setContentView(root)
        U.edgeToEdge(this)
    }
}
