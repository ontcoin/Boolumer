package com.boolumer.stream

import android.view.View
import android.widget.ImageView
import android.widget.TextView

/** Withdraw: Crypto / Cash, amount tiers, coin choice. Requests are only recorded on this phone. */
class WithdrawDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.withdraw_dialog_fragment
    private val amounts = intArrayOf(11200, 30600, 61200, 102000)
    private val usd = intArrayOf(1, 3, 6, 10)
    private val amtTxt = intArrayOf(R.id.textview13, R.id.textview14, R.id.textview17, R.id.textview15)
    private val coins = arrayOf("Bitcoin", "Ton", "Solana", "DogeCoin")
    private val coinImg = intArrayOf(R.id.image1, R.id.image2, R.id.image3, R.id.image4)
    private val coinLbl = intArrayOf(R.id.textview18, R.id.textview19, R.id.textview20, R.id.textview21)
    private val coinSvg = arrayOf("bitcoin-btc-logo.svg", "toncoin-ton-logo.svg", "solana-sol-logo.svg", "dogecoin-doge-logo.svg")
    private var amt = 0
    private var coin = 0
    private var crypto = true
    private lateinit var root: View

    override fun bind(root: View) {
        this.root = root
        click(root.f(R.id.imageview11)) { dismiss() }
        root.f<TextView>(R.id.textview2).text = U.num(Store.COINS_PER_USD, 0)
        for (i in 0 until 4) {
            root.f<TextView>(amtTxt[i]).text = U.num(amounts[i].toDouble(), 0)
            click(root.f(amtTxt[i])) { amt = i; paint() }
            U.svg(requireContext(), root.f<ImageView>(coinImg[i]), coinSvg[i])
            click(root.f(coinLbl[i])) { coin = i; paint() }
            root.f<View>(coinImg[i]).setOnClickListener { coin = i; paint() }
        }
        click(root.f(R.id.textview25)) { crypto = true; paint() }
        click(root.f(R.id.textview26)) { crypto = false; paint(); U.toast(requireContext(), "Cash withdrawals: coming soon") }
        click(root.f(R.id.address)) {
            PaymentDialogFragmentActivity().also { it.onClosed = { paint() } }.show(parentFragmentManager, "pay")
        }
        root.f<View>(R.id.lottie1).visibility = View.GONE
        click(root.f(R.id.textview12)) { submit() }
        paint()
    }

    private fun paint() {
        for (i in 0 until 4) {
            (root.f<View>(amtTxt[i]).parent as View).alpha = if (i == amt) 1f else 0.5f
            (root.f<View>(coinLbl[i]).parent as View).alpha = if (i == coin) 1f else 0.5f
        }
        root.f<View>(R.id.textview5).visibility = if (crypto) View.GONE else View.VISIBLE
        root.f<View>(R.id.textview25).alpha = if (crypto) 1f else 0.5f
        root.f<View>(R.id.textview26).alpha = if (crypto) 0.5f else 1f
        val ex = Store.activeExchange(requireContext())
        val id = if (ex.isEmpty()) "" else Store.wallet(requireContext(), ex)
        root.f<TextView>(R.id.address).text = if (id.isEmpty()) "No Exchange ID added" else "$ex: $id"
        root.f<TextView>(R.id.textview3).text = "$" + usd[amt] + ".00"
    }

    private fun submit() {
        val c = requireContext()
        if (!crypto) { U.toast(c, "Cash withdrawals: coming soon"); return }
        val ex = Store.activeExchange(c)
        val id = if (ex.isEmpty()) "" else Store.wallet(c, ex)
        when {
            id.isEmpty() -> U.toast(c, "Add your exchange ID first")
            Store.coins(c) < amounts[amt] || !Store.spend(c, amounts[amt].toDouble()) -> U.toast(c, "Not enough coins")
            else -> {
                Store.addHistory(c, "Withdraw $${usd[amt]} (${coins[coin]})", -amounts[amt].toDouble(), "Pending")
                U.toast(c, "Withdrawal requested")
                dismiss()
            }
        }
    }
}
