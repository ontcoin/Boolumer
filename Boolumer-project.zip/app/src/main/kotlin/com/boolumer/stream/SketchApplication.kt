package com.boolumer.stream

import android.app.Application
import android.content.Intent
import android.os.Process
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

class SketchApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val fallback = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                startActivity(
                    Intent(applicationContext, DebugActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        .putExtra("error", sw.toString())
                )
                Process.killProcess(Process.myPid())
                exitProcess(1)
            } catch (x: Throwable) {
                fallback?.uncaughtException(t, e)
            }
        }
    }
}
