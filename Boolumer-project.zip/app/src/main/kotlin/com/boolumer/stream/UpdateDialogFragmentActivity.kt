package com.boolumer.stream

import android.view.View

class UpdateDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.update_dialog_fragment
    override val sheet = false

    override fun bind(root: View) {
        isCancelable = false
        click(root.f(R.id.textview12)) { U.open(requireContext(), getString(R.string.url_update)) }
    }
}
