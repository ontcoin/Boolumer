package com.boolumer.stream

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Splash, then straight to Login or Home. */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main)
        U.edgeToEdge(this)
        lifecycleScope.launch {
            delay(1500)
            val next = if (Store.loggedIn(this@MainActivity)) HomeActivity::class.java else AuthenticationActivity::class.java
            startActivity(Intent(this@MainActivity, next))
            finish()
        }
    }
}
