package com.boolumer.stream

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random

/** Local-only app state (SharedPreferences). No backend: everything is simulated on the device. */
object Store {
    const val COINS_PER_USD = 11000.0
    const val EARN_PER_SECOND = 0.002
    val EXCHANGES = arrayOf("Binance", "Kucoin", "Bitget", "Litoshi")

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("boolumer", Context.MODE_PRIVATE)

    // ---------- session ----------
    fun loggedIn(c: Context) = sp(c).getBoolean("logged", false)
    fun uid(c: Context): String = sp(c).getString("uid", "") ?: ""
    fun name(c: Context): String = sp(c).getString("name", "") ?: ""
    fun email(c: Context): String = sp(c).getString("email", "") ?: ""

    fun login(c: Context, name: String, email: String) {
        val e = sp(c).edit().putBoolean("logged", true).putString("name", name).putString("email", email)
        if (uid(c).isEmpty()) e.putString("uid", (makeCode() + makeCode()).lowercase(Locale.US))
        if ((sp(c).getString("refCode", "") ?: "").isEmpty()) e.putString("refCode", makeCode())
        e.apply()
    }

    fun logout(c: Context) = sp(c).edit().clear().apply()

    private fun makeCode(): String {
        val a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = Random()
        return (1..7).map { a[r.nextInt(a.length)] }.joinToString("")
    }

    // ---------- coins ----------
    fun coins(c: Context): Double = Double.fromBits(sp(c).getLong("coins", 0.0.toBits()))
    private fun putCoins(c: Context, v: Double) = sp(c).edit().putLong("coins", v.toBits()).apply()

    fun addCoins(c: Context, v: Double, title: String) {
        putCoins(c, coins(c) + v)
        addHistory(c, title, v, "Success")
    }

    fun spend(c: Context, v: Double): Boolean {
        if (coins(c) < v) return false
        putCoins(c, coins(c) - v)
        return true
    }

    fun usd(c: Context) = coins(c) / COINS_PER_USD

    // ---------- wallets ----------
    fun wallet(c: Context, ex: String): String = sp(c).getString("w_$ex", "") ?: ""
    fun setWallet(c: Context, ex: String, id: String) =
        sp(c).edit().putString("w_$ex", id).putString("activeEx", ex).apply()
    fun activeExchange(c: Context): String = sp(c).getString("activeEx", "") ?: ""

    // ---------- referrals (simulated) ----------
    fun refCode(c: Context): String {
        var r = sp(c).getString("refCode", "") ?: ""
        if (r.isEmpty()) { r = makeCode(); sp(c).edit().putString("refCode", r).apply() }
        return r
    }
    fun refAsked(c: Context) = sp(c).getBoolean("refAsked", false)
    fun friends(c: Context) = sp(c).getInt("friends", 0)
    fun refReward(c: Context): Double = Double.fromBits(sp(c).getLong("refReward", 0.0.toBits()))

    fun useInviteCode(c: Context, code: String) {
        sp(c).edit().putBoolean("refAsked", true).putString("referredBy", code.trim().uppercase(Locale.US)).apply()
    }

    fun skipInvite(c: Context) = sp(c).edit().putBoolean("refAsked", true).apply()

    /** Simulation: a friend joins and adds a pending referral reward. */
    fun simulateFriendActivity(c: Context) {
        sp(c).edit().putInt("friends", friends(c) + 1)
            .putLong("refReward", (refReward(c) + 5 + Random().nextInt(20)).toBits()).apply()
    }

    fun claimRefReward(c: Context) {
        val r = refReward(c)
        if (r <= 0) return
        sp(c).edit().putLong("refReward", 0.0.toBits()).apply()
        putCoins(c, coins(c) + r)
        addHistory(c, "Referral reward", r, "Success")
    }

    // ---------- music permission bookkeeping ----------
    fun permissionAsked(c: Context) = sp(c).getBoolean("permAsked", false)
    fun setPermissionAsked(c: Context) = sp(c).edit().putBoolean("permAsked", true).apply()

    // ---------- history ----------
    fun history(c: Context): JSONArray = try {
        JSONArray(sp(c).getString("history", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    fun addHistory(c: Context, title: String, amount: Double, status: String) {
        try {
            val a = history(c)
            a.put(JSONObject().apply {
                put("title", title); put("amount", amount); put("status", status)
                put("date", SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(Date()))
            })
            val b = JSONArray()
            for (i in maxOf(0, a.length() - 200) until a.length()) b.put(a.get(i))
            sp(c).edit().putString("history", b.toString()).apply()
        } catch (_: Exception) {
        }
    }
}
