package com.boolumer.stream

import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class BlockedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.blocked)
        U.edgeToEdge(this)
        val support = findViewById<View>(R.id.textview11)
        val open = View.OnClickListener { U.open(this, getString(R.string.url_support)) }
        support.setOnClickListener(open)
        (support.parent as? View)?.takeIf { it !is CardView }?.setOnClickListener(open)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = finish()
        })
    }
}
