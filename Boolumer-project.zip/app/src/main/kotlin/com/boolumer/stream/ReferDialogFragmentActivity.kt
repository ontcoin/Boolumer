package com.boolumer.stream

import android.view.View
import android.widget.EditText

/** "Enter your invitation code" sheet (Skip / Submit). Simulated: any code is accepted. */
class ReferDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.refer_dialog_fragment

    override fun bind(root: View) {
        val code = root.f<EditText>(R.id.edittext1)
        root.f<View>(R.id.lottie1).visibility = View.GONE
        click(root.f(R.id.textBt1)) { Store.skipInvite(requireContext()); dismiss() }
        click(root.f(R.id.textview11)) {
            val c = code.text.toString().trim()
            if (c.isEmpty()) {
                U.toast(requireContext(), "Enter an invitation code")
            } else {
                Store.useInviteCode(requireContext(), c)
                U.toast(requireContext(), "Invitation applied")
                dismiss()
            }
        }
    }
}
