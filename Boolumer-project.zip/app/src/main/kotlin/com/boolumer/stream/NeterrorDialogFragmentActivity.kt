package com.boolumer.stream

import android.view.View

/** "Connection error" card with a Try Again button. */
class NeterrorDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.neterror_dialog_fragment
    override val sheet = false
    var onRetry: (() -> Unit)? = null

    override fun bind(root: View) {
        click(root.f(R.id.textview12)) { dismiss(); onRetry?.invoke() }
    }
}
