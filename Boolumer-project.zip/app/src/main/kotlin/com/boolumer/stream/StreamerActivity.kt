package com.boolumer.stream

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import com.airbnb.lottie.LottieAnimationView

/** "Streaming": plays a local track and accumulates coins while it plays; Claim banks them. */
class StreamerActivity : AppCompatActivity() {
    private val h = Handler(Looper.getMainLooper())
    private var earned = 0.0
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var earnedTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var playIcon: ImageView
    private lateinit var repeatIv: ImageView
    private lateinit var lottie: LottieAnimationView

    private val tick = object : Runnable {
        override fun run() {
            if (MusicPlayer.isPrepared) {
                seek.progress = MusicPlayer.position
                // coins are only earned while the song is playing and this screen is visible
                if (MusicPlayer.isPlaying && lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                    earned += Store.EARN_PER_SECOND * 0.5
                    earnedTv.text = U.num(earned, 2)
                }
                val size = MusicPlayer.current?.sizeText ?: ""
                sub.text = "${U.mmss(MusicPlayer.position.toLong())} / ${U.mmss(MusicPlayer.duration.toLong())}  ·  $size"
            }
            h.postDelayed(this, 500)
        }
    }

    private val listener = object : MusicPlayer.Listener {
        override fun onPreparing(song: Song) {
            title.text = song.title
            sub.text = song.artist
            seek.progress = 0
            playIcon.visibility = View.INVISIBLE
            lottie.visibility = View.VISIBLE
            lottie.setAnimation("spinner.json")
            lottie.playAnimation()
        }
        override fun onReady(song: Song) {
            seek.max = MusicPlayer.duration
            lottie.cancelAnimation()
            lottie.visibility = View.GONE
            playIcon.visibility = View.VISIBLE
        }
        override fun onPlayingChanged(playing: Boolean) {
            playIcon.setImageResource(if (playing) R.drawable.icon_pause_round else R.drawable.icon_play_arrow_round)
        }
        override fun onError() {
            lottie.cancelAnimation(); lottie.visibility = View.GONE; playIcon.visibility = View.VISIBLE
            U.toast(this@StreamerActivity, "Can't play this file")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.streamer)
        U.edgeToEdge(this)
        title = findViewById(R.id.title)
        sub = findViewById(R.id.textview5)
        earnedTv = findViewById(R.id.textview6)
        seek = findViewById(R.id.seekbar1)
        playIcon = findViewById(R.id.image)
        repeatIv = findViewById(R.id.imageview12)
        lottie = findViewById(R.id.lottie1)
        lottie.visibility = View.GONE
        // loading skeletons are not needed once real data is shown
        intArrayOf(R.id.card1, R.id.card2, R.id.lin, R.id.cardview36).forEach { findViewById<View>(it)?.visibility = View.GONE }

        if (MusicRepository.songs.isEmpty()) { finish(); return }

        findViewById<View>(R.id.imageview11).setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        findViewById<View>(R.id.linBt).setOnClickListener { MusicPlayer.toggle() }
        findViewById<View>(R.id.f_bt).setOnClickListener { MusicPlayer.next(this) }
        findViewById<View>(R.id.b_bt).setOnClickListener { MusicPlayer.previous(this) }
        repeatIv.alpha = 0.5f
        repeatIv.setOnClickListener {
            MusicPlayer.repeatOne = !MusicPlayer.repeatOne
            repeatIv.alpha = if (MusicPlayer.repeatOne) 1f else 0.5f
        }
        findViewById<View>(R.id.imageview13).setOnClickListener {
            ListMusicDialogFragmentActivity().also { d ->
                d.onPick = { MusicPlayer.play(this, it) }
            }.show(supportFragmentManager, "queue")
        }
        findViewById<View>(R.id.textview7).setOnClickListener { claim() }
        (findViewById<View>(R.id.textview7).parent as? View)?.setOnClickListener { claim() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) MusicPlayer.seekTo(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (earned > 0.0001) {
                    CoinbackpressDialogFragmentActivity().also { d ->
                        d.onLeave = { earned = 0.0; finish() }
                    }.show(supportFragmentManager, "leave")
                } else finish()
            }
        })

        MusicPlayer.listener = listener
        MusicPlayer.play(this, intent.getIntExtra("index", 0))
        h.post(tick)
    }

    private fun claim() {
        if (earned <= 0.0001) { U.toast(this, "Keep streaming to earn coins"); return }
        val song = MusicPlayer.current?.title ?: "track"
        Store.addCoins(this, earned, "Stream: $song")
        U.toast(this, "+" + U.num(earned, 2) + " coins claimed")
        earned = 0.0
        earnedTv.text = "0.00"
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        MusicPlayer.listener = null
        MusicPlayer.stop()
        super.onDestroy()
    }
}
