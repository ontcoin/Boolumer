package com.boolumer.stream

import android.app.Dialog
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.DialogFragment

/** Shared behaviour of all the "*DialogFragmentActivity" screens: bottom sheets and centred alerts. */
abstract class BaseDialog : DialogFragment() {
    protected abstract val layoutRes: Int
    protected abstract fun bind(root: View)

    /** true = bottom sheet, false = centred alert card */
    protected open val sheet: Boolean get() = true

    /** Called after the dialog goes away (Home uses it to refresh the balance). */
    var onClosed: (() -> Unit)? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        Dialog(requireContext(), R.style.BottomDialog).apply { requestWindowFeature(Window.FEATURE_NO_TITLE) }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val v = inflater.inflate(layoutRes, container, false)
        if (v is LinearLayout && v.childCount > 0) {
            v.gravity = if (sheet) Gravity.BOTTOM else Gravity.CENTER
            val card = v.getChildAt(0)
            var c = U.bgColor(card, 0xFF151515.toInt())
            if (Color.alpha(c) == 0) c = 0xFF151515.toInt()
            card.background = U.round(c, U.dp(requireContext(), if (sheet) 28f else 24f).toFloat(), sheet)
            card.isClickable = true
            v.setOnClickListener { if (isCancelable) dismiss() }
        }
        bind(v)
        return v
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setDimAmount(0.65f)
        }
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        onClosed?.invoke()
    }

    protected fun <T : View> View.f(id: Int): T = findViewById(id)

    /** Makes the clickable parent row/button react, not just the text or icon. */
    protected fun click(v: View?, l: (View) -> Unit) {
        v ?: return
        var target = v
        if ((v is TextView || v is ImageView) && v.parent is ViewGroup && v.parent !is CardView) target = v.parent as View
        target.setOnClickListener(l)
        if (target !== v) v.setOnClickListener(l)
    }
}
