package com.boolumer.stream

import android.view.View
import android.widget.TextView

/** Friendly "Allow music access" sheet shown before the system permission prompt. */
class PermissionDialogFragment : BaseDialog() {
    override val layoutRes = R.layout.permission_dialog
    var openSettings = false
    var onAllow: (() -> Unit)? = null
    var onLater: (() -> Unit)? = null

    override fun bind(root: View) {
        if (openSettings) {
            root.f<TextView>(R.id.pTitle).text = "Music access is turned off"
            root.f<TextView>(R.id.pDesc).text =
                "Open Settings, tap Permissions and allow Music and audio, then come back to Boolumer."
            root.f<TextView>(R.id.pAllowText).text = "Open Settings"
        }
        root.f<View>(R.id.pAllow).setOnClickListener {
            dismiss()
            if (openSettings) MusicPermission.openSettings(requireContext()) else onAllow?.invoke()
        }
        root.f<View>(R.id.pLater).setOnClickListener { dismiss(); onLater?.invoke() }
    }
}
