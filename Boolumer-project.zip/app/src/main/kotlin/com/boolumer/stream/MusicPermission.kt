package com.boolumer.stream

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Everything about the permission needed to read music:
 *  - Android 7 to 12 (API 24-32): READ_EXTERNAL_STORAGE
 *  - Android 13+ (API 33+)      : READ_MEDIA_AUDIO
 */
object MusicPermission {
    val permission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun isGranted(c: Context) =
        ContextCompat.checkSelfPermission(c, permission) == PackageManager.PERMISSION_GRANTED

    /** True when the user ticked "don't ask again" (or denied twice): only Settings can fix it. */
    fun isPermanentlyDenied(a: Activity) =
        !isGranted(a) && Store.permissionAsked(a) && !ActivityCompat.shouldShowRequestPermissionRationale(a, permission)

    fun openSettings(c: Context) {
        c.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", c.packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
