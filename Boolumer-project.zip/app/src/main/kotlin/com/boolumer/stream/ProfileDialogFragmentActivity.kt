package com.boolumer.stream

import android.content.Intent
import android.view.View
import android.widget.ImageView
import android.widget.TextView

class ProfileDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.profile_dialog_fragment

    override fun bind(root: View) {
        val c = requireContext()
        click(root.f(R.id.imageview11)) { dismiss() }
        val avatar = root.f<ImageView>(R.id.imageview14)
        if (avatar.drawable == null) avatar.setImageResource(R.drawable.default_image)
        root.f<TextView>(R.id.textview2).text = Store.name(c).ifEmpty { "- - -" }
        root.f<TextView>(R.id.textview9).text = Store.email(c).ifEmpty { "- - -" }
        val uid = Store.uid(c)
        root.f<TextView>(R.id.textview3).text = "ID: " + if (uid.isEmpty()) "- - -" else uid.take(8)
        try {
            val v = c.packageManager.getPackageInfo(c.packageName, 0).versionName
            root.f<TextView>(R.id.textview8).text = "Version $v"
        } catch (_: Exception) {
        }
        icon(root, R.id.image5, R.drawable.icon_checklist_round)
        icon(root, R.id.imageview12, R.drawable.icon_attach_money_round)
        icon(root, R.id.imageview16, R.drawable.icon_contact_support_twotone)
        icon(root, R.id.imageview15, R.drawable.icon_privacy_tip_twotone)
        icon(root, R.id.imageview5, R.drawable.icon_logout_round)
        intArrayOf(R.id.imm1, R.id.imm2, R.id.imm3, R.id.imm4, R.id.imm5, R.id.imm6)
            .forEach { icon(root, it, R.drawable.icon_arrow_forward_ios_round) }

        click(root.f(R.id.text1)) { dismiss(); startActivity(Intent(c, TaskActivity::class.java)) }
        click(root.f(R.id.text2)) { dismiss(); PaymentDialogFragmentActivity().show(parentFragmentManager, "pay") }
        click(root.f(R.id.text3)) { U.open(c, getString(R.string.url_support)) }
        click(root.f(R.id.text4)) { U.open(c, getString(R.string.url_privacy)) }
        click(root.f(R.id.textview4)) { dismiss(); SignoutDialogFragmentActivity().show(parentFragmentManager, "out") }
    }

    private fun icon(r: View, id: Int, res: Int) {
        val iv = r.findViewById<ImageView>(id)
        if (iv != null && iv.drawable == null) iv.setImageResource(res)
    }
}
