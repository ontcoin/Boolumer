package com.boolumer.stream

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reads the audio library (MediaStore) and keeps the current list for every screen. */
object MusicRepository {
    /** Current library, shared by Home, Streamer and the queue dialog. */
    val songs: MutableList<Song> = mutableListOf()

    private const val MIN_DURATION_MS = 30_000

    /** Scans the phone for music. Safe to call again at any time (= refresh). */
    suspend fun refresh(context: Context): List<Song> = withContext(Dispatchers.IO) {
        val found = query(context.applicationContext)
        withContext(Dispatchers.Main) {
            songs.clear()
            songs.addAll(found)
        }
        found
    }

    private fun query(c: Context): List<Song> {
        if (!MusicPermission.isGranted(c)) return emptyList()
        val out = ArrayList<Song>()
        val a = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        try {
            c.contentResolver.query(
                a, projection, selection, arrayOf(MIN_DURATION_MS.toString()),
                "${MediaStore.Audio.Media.DATE_ADDED} DESC"
            )?.use { cur ->
                val iId = cur.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iDur = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iSize = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val iDate = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                while (cur.moveToNext()) {
                    val id = cur.getLong(iId)
                    out += Song(
                        id = id,
                        title = cur.getString(iTitle) ?: "Unknown",
                        artist = cur.getString(iArtist)?.takeIf { it != "<unknown>" } ?: "Unknown artist",
                        album = cur.getString(iAlbum) ?: "",
                        durationMs = cur.getLong(iDur),
                        sizeBytes = cur.getLong(iSize),
                        uri = ContentUris.withAppendedId(a, id),
                        dateAdded = cur.getLong(iDate)
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}
