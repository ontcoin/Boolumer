package com.boolumer.stream

import android.content.Intent
import android.view.View

class SignoutDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.signout_dialog_fragment
    override val sheet = false

    override fun bind(root: View) {
        click(root.f(R.id.textview12)) { dismiss() }
        click(root.f(R.id.textview13)) {
            MusicPlayer.stop()
            Store.logout(requireContext())
            MusicRepository.songs.clear()
            startActivity(
                Intent(requireContext(), AuthenticationActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
        }
    }
}
