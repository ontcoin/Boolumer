package com.boolumer.stream

import android.net.Uri

/** One audio file found on the phone. */
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val uri: Uri,
    val dateAdded: Long
) {
    /** Coins you can earn by streaming the whole track. */
    val reward: Double get() = Math.round(durationMs / 1000.0 * Store.EARN_PER_SECOND * 10.0) / 10.0
    val sizeText: String get() = U.sizeText(sizeBytes)
}
