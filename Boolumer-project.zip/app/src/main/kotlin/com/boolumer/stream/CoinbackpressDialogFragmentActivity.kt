package com.boolumer.stream

import android.view.View

/** "Claim Reward" warning shown when leaving the Streamer with unclaimed coins. */
class CoinbackpressDialogFragmentActivity : BaseDialog() {
    override val layoutRes = R.layout.coinbackpress_dialog_fragment
    override val sheet = false
    var onLeave: (() -> Unit)? = null

    override fun bind(root: View) {
        click(root.f(R.id.textview12)) { dismiss() }
        click(root.f(R.id.textview13)) { dismiss(); onLeave?.invoke() }
    }
}
