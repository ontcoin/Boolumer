package com.boolumer.stream

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.PowerManager

/** Single app-wide player: play, pause, resume, next, previous, seek, repeat and audio focus handling. */
object MusicPlayer {
    interface Listener {
        fun onPreparing(song: Song)
        fun onReady(song: Song)
        fun onPlayingChanged(playing: Boolean)
        fun onError()
    }

    private var mp: MediaPlayer? = null
    private var prepared = false
    private var focusRequest: AudioFocusRequest? = null
    private var pausedByFocus = false

    var index = 0
        private set
    var repeatOne = false
    var listener: Listener? = null

    val isPrepared get() = prepared
    val isPlaying: Boolean get() = try { mp?.isPlaying == true } catch (_: IllegalStateException) { false }
    val position: Int get() = if (prepared) try { mp?.currentPosition ?: 0 } catch (_: Exception) { 0 } else 0
    val duration: Int get() = if (prepared) try { mp?.duration ?: 0 } catch (_: Exception) { 0 } else 0
    val current: Song? get() = MusicRepository.songs.getOrNull(index)

    fun play(ctx: Context, i: Int) {
        val list = MusicRepository.songs
        if (list.isEmpty()) return
        index = ((i % list.size) + list.size) % list.size
        val song = list[index]
        val app = ctx.applicationContext
        releasePlayer()
        prepared = false
        listener?.onPreparing(song)
        try {
            mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA).build()
                )
                setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(app, song.uri)
                setOnPreparedListener { m ->
                    prepared = true
                    if (requestFocus(app)) m.start()
                    listener?.onReady(song)
                    listener?.onPlayingChanged(isPlaying)
                }
                setOnCompletionListener { if (repeatOne) play(app, index) else next(app) }
                setOnErrorListener { _, _, _ -> prepared = false; listener?.onError(); true }
                prepareAsync()
            }
        } catch (_: Exception) {
            listener?.onError()
        }
    }

    fun toggle() { if (isPlaying) pause() else resume() }

    fun pause() {
        if (prepared && isPlaying) { mp?.pause(); listener?.onPlayingChanged(false) }
    }

    fun resume() {
        val app = mp ?: return
        if (prepared && !isPlaying) { app.start(); listener?.onPlayingChanged(true) }
    }

    fun next(ctx: Context) = play(ctx, index + 1)
    fun previous(ctx: Context) = play(ctx, index - 1)

    fun seekTo(ms: Int) { if (prepared) try { mp?.seekTo(ms) } catch (_: Exception) { } }

    /** Stops playback and frees everything. */
    fun stop() {
        releasePlayer()
        abandonFocus()
        prepared = false
    }

    private fun releasePlayer() {
        mp?.let { try { it.release() } catch (_: Exception) { } }
        mp = null
    }

    // ---------- audio focus ----------
    private var am: AudioManager? = null
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> pause()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (isPlaying) { pausedByFocus = true; pause() }
            }
            AudioManager.AUDIOFOCUS_GAIN -> if (pausedByFocus) { pausedByFocus = false; resume() }
        }
    }

    @Suppress("DEPRECATION")
    private fun requestFocus(c: Context): Boolean {
        val m = am ?: (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { am = it }
        return if (Build.VERSION.SDK_INT >= 26) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setOnAudioFocusChangeListener(focusListener).build()
            focusRequest = req
            m.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            m.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) ==
                AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }

    @Suppress("DEPRECATION")
    private fun abandonFocus() {
        val m = am ?: return
        if (Build.VERSION.SDK_INT >= 26) focusRequest?.let { m.abandonAudioFocusRequest(it) }
        else m.abandonAudioFocus(focusListener)
    }
}
