package com.boolumer.stream

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Login: "Sign up with Google" and "Demo Login" just show the loader and take you into the app. */
class AuthenticationActivity : AppCompatActivity() {
    private var loading: Dialog? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.authentication)
        U.edgeToEdge(this)
        findViewById<android.view.View>(R.id.lin).setOnClickListener { signIn("Boolumer User", "user@boolumer.app") }
        findViewById<android.view.View>(R.id.linear13).setOnClickListener { signIn("Demo User", "demo@boolumer.app") }
        findViewById<android.view.View>(R.id.t_4).setOnClickListener { U.open(this, getString(R.string.url_terms)) }
        findViewById<android.view.View>(R.id.imageview4).setOnLongClickListener { DemoNav.show(this); true }
    }

    private fun signIn(name: String, email: String) {
        if (busy) return
        busy = true
        showLoading()
        lifecycleScope.launch {
            delay(1300)
            Store.login(this@AuthenticationActivity, name, email)
            dismissLoading()
            startActivity(Intent(this@AuthenticationActivity, HomeActivity::class.java))
            finish()
        }
    }

    private fun showLoading() {
        loading = Dialog(this).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(R.layout.loading)
            setCancelable(false)
            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            show()
        }
    }

    private fun dismissLoading() {
        loading?.takeIf { it.isShowing }?.dismiss()
        loading = null
    }

    override fun onDestroy() {
        dismissLoading()
        super.onDestroy()
    }
}
