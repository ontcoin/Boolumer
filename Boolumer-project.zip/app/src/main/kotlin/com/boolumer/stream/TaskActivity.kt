package com.boolumer.stream

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/** Tasks screen ("Coming Soon", same as the original). */
class TaskActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.task)
        U.edgeToEdge(this)
        findViewById<android.view.View>(R.id.imageview11).setOnClickListener { finish() }
    }
}
