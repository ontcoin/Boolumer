package com.boolumer.stream

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.FragmentActivity

/** Screen navigator: long-press the greeting on Home (or the logo on Login) to jump to ANY screen or dialog. */
object DemoNav {
    fun show(a: Activity) {
        val items = arrayOf(
            "Splash (Main)", "Login (Authentication)", "Home", "Streamer", "Tasks", "Maintenance", "Blocked",
            "Debug (crash screen)", "Withdraw", "Referral", "Invitation code", "History", "Payment", "Profile",
            "Music list", "Sign out", "Update available", "Connection error", "Claim reward warning",
            "Music permission dialog", "Add simulated friend reward"
        )
        AlertDialog.Builder(a).setTitle("Go to screen").setItems(items) { _, w ->
            fun go(c: Class<*>) = a.startActivity(Intent(a, c))
            val noMusic = MusicRepository.songs.isEmpty()
            when (w) {
                0 -> go(MainActivity::class.java)
                1 -> go(AuthenticationActivity::class.java)
                2 -> go(HomeActivity::class.java)
                3 -> if (noMusic) U.toast(a, "No music found yet. Open Home and allow music access first")
                     else a.startActivity(Intent(a, StreamerActivity::class.java).putExtra("index", 0))
                4 -> go(TaskActivity::class.java)
                5 -> go(MaintenanceActivity::class.java)
                6 -> go(BlockedActivity::class.java)
                7 -> a.startActivity(Intent(a, DebugActivity::class.java)
                    .putExtra("error", "Simulated crash screen\njava.lang.RuntimeException: demo"))
                20 -> { Store.simulateFriendActivity(a); U.toast(a, "A friend joined: reward added") }
                else -> {
                    val fm = (a as? FragmentActivity)?.supportFragmentManager ?: return@setItems
                    val f: BaseDialog = when (w) {
                        8 -> WithdrawDialogFragmentActivity()
                        9 -> ReferralDialogFragmentActivity()
                        10 -> ReferDialogFragmentActivity()
                        11 -> HistoryDialogFragmentActivity()
                        12 -> PaymentDialogFragmentActivity()
                        13 -> ProfileDialogFragmentActivity()
                        14 -> { if (noMusic) { U.toast(a, "No music found yet"); return@setItems }; ListMusicDialogFragmentActivity() }
                        15 -> SignoutDialogFragmentActivity()
                        16 -> UpdateDialogFragmentActivity()
                        17 -> NeterrorDialogFragmentActivity()
                        18 -> CoinbackpressDialogFragmentActivity()
                        else -> PermissionDialogFragment()
                    }
                    f.show(fm, "nav")
                }
            }
        }.show()
    }
}
