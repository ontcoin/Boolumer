# Boolumer – 100% Kotlin, offline build

Package `com.boolumer.stream`, Android 7.0 (API 24) and above. No backend, no ads, no internet permission.

## Stack (latest)
AGP 8.11.1, Gradle 8.13, Kotlin 2.0.21, JDK 17, compileSdk 36 / targetSdk 36, AndroidX, Material 1.12, Lottie 6.6, coroutines.

## Music
- `MusicPermission`  : READ_MEDIA_AUDIO on Android 13+, READ_EXTERNAL_STORAGE on Android 7-12; detects "denied forever" and opens Settings.
- `PermissionDialogFragment` : the "Allow music access" sheet shown before the system prompt.
- `MusicRepository`  : MediaStore scan (title, artist, album, duration, SIZE, date) + refresh. 
- `MusicPlayer`      : play, pause, resume, next, previous, seek, repeat-one, audio focus, wake lock.
- Home refresh icon (Task Drop row) or tapping "No music found" re-scans.

## Navigation / demo
Login buttons show the loader and enter the app. Long-press the greeting on Home (or the logo on Login) to jump to any screen/dialog.

## Build
`.github/workflows/build.yml` -> debug APK, release APK, release AAB. Signing env vars: KEYSTORE_FILE, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.

## One-zip build
Extract this zip into the root of a **private** GitHub repo and push to main. It already contains everything the workflow needs:
`.github/workflows/build.yml`, the release key `app/build.jks`, its passwords (gradle.properties) and `EXPECTED_SHA256.txt`.
No GitHub secrets are required. Downloads: Actions run -> Artifacts -> Boolumer-APK / Boolumer-AAB-for-PlayStore.
